const credential =
{
     ID  : '838997555612-u3v6grj1576h6sv7aec93gpagd2n7837.apps.googleusercontent.com',
     KEY : 'AIzaSyAJjjqFdUZieoriEBmnBqI4zZDECFdE1Tw',
     TOK : 'ya29.A0ARrdaM9GP9C_7XQFuZhfA2fka4Tz_KYDUeXOyzA_aqycleeAUnQ11I1TdzsLb9cJCTv1MrlRmHg5sBZaf-dK9twRZp1bNUjSFL9cv6PSvcWGXJBig0msOsg3spvN2iEB0Sxa4phxr6BfU0big8fIGyml4Wqq'
};

export default {
    credential
};